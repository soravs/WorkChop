﻿import { Component, OnInit, Injector, ViewEncapsulation, AfterViewInit, Inject } from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Http } from '@angular/http';
import { API_BASE_URL } from '@shared/service-proxies/service-proxies';
import { Observable } from 'rxjs/Observable';
import * as _ from "lodash";
import * as moment from 'moment';

import {
    BenAdmin,
    Carrier,
    BenAdminServiceProxy,
    CarrierServiceProxy,
    Group,
    GroupServiceProxy,
    ImportCarrierDataAppServiceProxy,
    ImportJobAppServiceProxy,
    TpaJobAppServiceProxy,
    SearchDto,
    TpaJobSearchDto
} from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './benadmin-receiver-status.component.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./benadmin-receiver-status.component.css']
})

export class BenAdminReceiverStatusComponent extends AppComponentBase implements OnInit {

    public baseUrl: string = undefined;

    public csvApiUrl: string = "/api/services/app/TpaJob/GetCsvFile/?tpaJobId=##ID##";

    public filters = new Filters(null);
    public benAdmins: BenAdmin[] = [];
    public benAdminId: number;

    public startDate: moment.Moment = moment().startOf("day");
    public endDate: moment.Moment = moment().endOf("day");
    public moment = moment;


    public tpaJobs: any = null;
    public areTpaJobsLoading: boolean = false;

    constructor(
        injector: Injector,
        private _http: Http,
        private _benAdminService: BenAdminServiceProxy,
        private _tpaJobService: TpaJobAppServiceProxy,
        @Inject(API_BASE_URL) baseUrl?: string
    ) {
        super(injector);
        this.baseUrl = baseUrl ? baseUrl : "";
    }

    ngOnInit(): void {

        let self_ = this;

        abp.ui.setBusy();

        this._benAdminService.getBenAdmins().finally(function () { abp.ui.clearBusy(); }).subscribe((resp) => {
            let defaultBenAdmin = new BenAdmin();
            defaultBenAdmin.name = "No BenAdmin(s) Available";
            defaultBenAdmin.id = 0;
            this.benAdmins = resp.items.length === 0 ? [defaultBenAdmin] : resp.items;
            this.filters.benAdminId = this.benAdmins[0].id;
            this.getDataBasedOnSelectedFilters(this.filters.benAdminId, this.startDate, this.endDate);
        });
    }

    getDataBasedOnSelectedFilters(benAdminId: number, startDate: moment.Moment, endDate: moment.Moment): void {

        this.areTpaJobsLoading = true;

        let searchDto = new TpaJobSearchDto();
        searchDto.benAdminId = benAdminId;
        searchDto.startDate = startDate;
        searchDto.endDate = endDate;

        this._tpaJobService.tpaJobs(searchDto).finally(function () { abp.ui.clearBusy(); this.areTpaJobsLoading = false; }).subscribe((resp) => {
          
            if (resp !== null) {

                let _self = this;

                this.tpaJobs = resp;

                //modify the  response and adds the csv download url to download the CSV file
                _.forEach(this.tpaJobs, function (data, index) {
                    data.csvDownloadUrl = _self.baseUrl + _self.csvApiUrl.replace("##ID##", data.id);
                })
            }               
        });
    }

    benAdminOnChange(benAdminId: number): void {
        this.filters.benAdminId = benAdminId;
    }

    onRefreshClick(): void {
        abp.ui.setBusy();
        this.getDataBasedOnSelectedFilters(this.filters.benAdminId, this.startDate, this.endDate);
    }
}

export class Filters {
    constructor(
        public benAdminId?: number        
    ) { }
}
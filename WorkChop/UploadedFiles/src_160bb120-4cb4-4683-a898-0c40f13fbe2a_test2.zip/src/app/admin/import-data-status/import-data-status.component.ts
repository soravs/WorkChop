﻿import { Component, OnInit, Injector, ViewEncapsulation, AfterViewInit, Inject } from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { Http } from '@angular/http';
import { API_BASE_URL } from '@shared/service-proxies/service-proxies';
import { Observable } from 'rxjs/Observable';
import * as _ from "lodash";
import * as moment from 'moment';

import {
    BenAdmin,
    Carrier,
    CarrierServiceProxy,
    Group,
    GroupServiceProxy,
    ImportCarrierDataAppServiceProxy,
    ImportJobAppServiceProxy,
    SearchDto
} from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './import-data-status.component.html',
    animations: [appModuleAnimation()],
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./import-data-status.component.css']
})

export class ImportDataStatusComponent extends AppComponentBase implements OnInit, AfterViewInit {

    public baseUrl: string = undefined;
    public csvApiUrl: string = "/api/services/app/ImportJob/GetCsvFile/?importJobId=##ID##";

    benAdmins: BenAdmin[] = [];
    carriers: Carrier[] = [];
    groups: any = [];

    public startDate: moment.Moment = moment().startOf("day");
    public endDate: moment.Moment = moment().endOf("day");

    public moment = moment;

    benAdminId: number;
    carrierId: number;
    groupId: number;

    public importJobs: any = null;
    public areImportJobsLoading: boolean = false;
    public filters = new Filters(null, null, null);

    constructor(
        injector: Injector,
        private _http: Http,
        private _importCarrierDataAppService: ImportCarrierDataAppServiceProxy,
        private _importJobAppService: ImportJobAppServiceProxy,
        @Inject(API_BASE_URL) baseUrl?: string
    ) {
        super(injector);
        this.baseUrl = baseUrl ? baseUrl : "";
    }

    ngOnInit(): void {

        var self_ = this;

        abp.ui.setBusy();

        //load import data filters
        //pass ben admin id = 0 because of the fact that we are loading the data first time
        this._importCarrierDataAppService.loadImportCarrierDataFilters(0).subscribe((res) => {

            let this_ = this;

            this.benAdmins = res.benAdmins.items;

            var defaultCarrier = new Carrier();
            defaultCarrier.carrierName = "No Carrier(s) Available";
            defaultCarrier.id = 0;

            this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

            this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

            _.forEach(res.groups.items, function (x) {
                this_.groups.push(x);
            })

            this.benAdminId = this.filters.benAdminId = this.benAdmins[0].id;
            this.groupId = this.filters.groupId = this.groups[0].id;
            this.carrierId = this.filters.carrierId = this.carriers[0].id;

            this.getDataBasedOnSelectedFilters(
                this.benAdminId,
                this.carrierId,
                this.groupId,
                this.startDate, this.endDate);
        });

    }

    ngAfterViewInit(): void { }

    getDataBasedOnSelectedFilters(benAdminId: number, carrierId: number, groupId: any, startDate: moment.Moment, endDate: moment.Moment): void {

        this.areImportJobsLoading = true

        let searchDto = new SearchDto();
        searchDto.benAdminId = benAdminId;
        searchDto.carrierId = carrierId;
        searchDto.clientId = groupId;
        searchDto.startDate = this.startDate;
        searchDto.endDate = this.endDate;

        this._importJobAppService.jobs(searchDto).finally(function () { abp.ui.clearBusy(); this.areImportJobsLoading = false; })
            .subscribe((resp) => {

                let _self = this;

                //modify the  response and adds the csv download url to download the CSV file
                _.forEach(resp, function (data, index) {
                    data.csvDownloadUrl = _self.baseUrl + _self.csvApiUrl.replace("##ID##", data.id);
                })

                this.importJobs = resp;
            });
    }

    carrierOnChange(carrierId: number): void {
        this.filters.carrierId = carrierId;
    }

    groupOnChange(groupId: number): void {
        this.filters.groupId = groupId;
    };

    //submit event of form
    onRefreshClick(event: any) {
        abp.ui.setBusy();
        this.carrierId = this.filters.carrierId;
        this.groupId = this.filters.groupId;
        this.benAdminId = this.filters.benAdminId;
        this.getDataBasedOnSelectedFilters(
            this.benAdminId,
            this.carrierId,
            this.groupId,
            this.startDate, this.endDate);
    }

    //downloads a CSV file for given imported id
    downloadCsvFile(importJobId: number): void {

        abp.ui.setBusy();

        this._importJobAppService.downloadCsvFile(importJobId).finally(function () { abp.ui.clearBusy(); }).subscribe((resp) => { });
    }

    benAdminOnChange(newValue): void {

        abp.ui.setBusy();

        this.filters.benAdminId = newValue;

        this._importCarrierDataAppService.loadImportCarrierDataFilters(this.filters.benAdminId)
            .finally(function () { abp.ui.clearBusy(); }).subscribe((res) => {

                let this_ = this;

                var defaultCarrier = new Carrier();
                defaultCarrier.carrierName = "No Carrier(s) Available";
                defaultCarrier.id = 0;

                this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

                this.groups = [];

                this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

                _.forEach(res.groups.items, function (x) {
                    this_.groups.push(x);
                })

                this.groupId = this.filters.groupId = this.groups[0].id;
                this.carrierId = this.filters.carrierId = this.carriers.length > 0 ? this.carriers[0].id : defaultCarrier.id;
            });
    }
}

export class Filters {
    constructor(
        public benAdminId?: number,
        public carrierId?: number,
        public groupId?: number
    ) { }
}
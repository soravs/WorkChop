export interface IBasicOrganizationUnitInfo {
    id: number;
    displayName: string;
}
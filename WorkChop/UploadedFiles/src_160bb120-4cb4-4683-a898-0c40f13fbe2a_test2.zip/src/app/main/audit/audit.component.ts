﻿import { Component, OnInit, AfterViewInit, Injector } from '@angular/core';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppComponentBase } from '@shared/common/app-component-base';

@Component({
    templateUrl: './audit.component.html',
    styleUrls: ['./audit.component.css'],
    animations: [appModuleAnimation()]
})
export class AuditComponent extends AppComponentBase implements AfterViewInit, OnInit {

    ngOnInit(): void {

    }

    ngAfterViewInit(): void {

    }
}
import { Component, OnInit, ViewChild, Injector, ElementRef, EventEmitter, Output, Inject } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ModalDirective } from 'ng2-bootstrap';
import { AppComponentBase } from '@shared/common/app-component-base';
import { AppConsts } from '@shared/AppConsts';
import { BenefitDefinitionProxy, BenefitType, CarrierInvoiceDto, CarrierInvoiceServiceProxy } from '@shared/service-proxies/service-proxies';
import * as moment from 'moment';
import { API_BASE_URL } from '@shared/service-proxies/service-proxies';
import * as _ from "lodash";

@Component({
    selector: 'carrierInvoicePdfModal',
    templateUrl: './carrier-invoice-pdf-modal.component.html',
    styleUrls: ['./carrier-invoice-pdf-modal.component.css']
})

export class CarrierInvoicePDFModalComponent extends AppComponentBase {

    @ViewChild('carrierInvoicePdfModal') modal: ModalDirective;

    public baseUrl: string = undefined;

    public moment = moment;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    public invoicePDFModel = new CarrierInvoiceDto();

    public benefitTypes: BenefitType[] = [];

    public modalHeaderText: string = "";

    saving: boolean = false;

    active: boolean = true;

    iframeActive: boolean = false;

    invoicePdfUrl: SafeUrl = undefined;

    carrierInvoiceData: any = null;

    modalElement: any;

    public coverageMonths: Array<any>;

    constructor(
        injector: Injector,
        private _benefitTypesService: BenefitDefinitionProxy,
        private _carrierInvoiceService: CarrierInvoiceServiceProxy,
        private _sanitizer: DomSanitizer,
        @Inject(API_BASE_URL) baseUrl?: string
    ) {
        super(injector);
        this.baseUrl = baseUrl ? baseUrl : "";
    }

    initializeModal(group: any): void {

        this.modalHeaderText = 'PDF Invoice from ' + group.carrierName + ' for ' + group.billingMonth.replace(',', '');

        //this functional gets called when the PDF is available and the click event is enabled for the group
        this.invoicePDFModel.isPDFAvailable = true;

        this.invoicePDFModel.id = group.carrierInvoice.id;

        this.invoicePDFModel.invoiceNumber = group.carrierInvoice.invoiceNumber;

        this.invoicePDFModel.invoiceFileName = group.carrierInvoice.invoiceFileName;

        this.invoicePDFModel.carrierGroupAccountId = group.carrierInvoice.carrierGroupAccountId;

        this.invoicePDFModel.receiptionMethod = group.carrierInvoice.receiptionMethod !== null ? group.carrierInvoice.receiptionMethod.trim() : 'Email'; //default to Email

        this.invoicePDFModel.benefitTypes = group.benefitDefinition.benefitType;

        this.invoicePDFModel.coverageStartDate = group.carrierInvoice.coverageStartDate;

        this.invoicePDFModel.dateReceived = group.carrierInvoice.dateReceived !== null ? moment(group.carrierInvoice.dateReceived).format("YYYY-MM-DD") : moment(new Date()).format("YYYY-MM-DD");

        this.invoicePDFModel.dueDate = group.carrierInvoice.dueDate !== null ? moment(group.carrierInvoice.dueDate).format("YYYY-MM-DD") : null;

        this.invoicePDFModel.invoiceAmount = group.carrierInvoice.invoiceAmount !== null ? group.carrierInvoice.invoiceAmount.toFixed(2) : 0.00.toFixed(2);

        this.invoicePDFModel.adjustmentAmount = group.carrierInvoice.adjustmentAmount !== null ? group.carrierInvoice.adjustmentAmount.toFixed(2) : 0.00.toFixed(2);

        this.invoicePDFModel.totalPremiumAmount = parseFloat(group.carrierInvoice.totalPremiumAmount).toFixed(2);

        this.invoicePDFModel.accountNumber = group.accountNumber;

        this.coverageMonths = this.getCoverageMonths();
    }

    adjustmentAmountOnChange(value: string) {
        value = value === '' ? '0' : value;
        this.invoicePDFModel.totalPremiumAmount = (parseFloat(value) + parseFloat(String(this.invoicePDFModel.invoiceAmount))).toFixed(2);
    }

    currentMonthlyPremiumOnChange(value: string) {
        value = value === '' ? '0' : value;
        this.invoicePDFModel.totalPremiumAmount = (parseFloat(value) + parseFloat(String(this.invoicePDFModel.adjustmentAmount))).toFixed(2);
    }

    mapCoverageTypes(coverageTypes: any): void {

        if (coverageTypes === '' || coverageTypes === null || coverageTypes === undefined) {
            return;
        }

        let types = coverageTypes.split(',');

        //replace spaces from string
        types = types.map(function (x) {
            return x.trim();
        });

        //default to false for all
        this.benefitTypes = _.filter(this.benefitTypes, function (x: any) { return x => x.isChecked = false; });

        _.forEach(this.benefitTypes, function (benefitType) {
            _.forEach(types, function (data) {
                if (data === benefitType.benefitType) {
                    benefitType.isChecked = true;
                }
            });
        });
    }

    receiptionMethodOnChange(receiptionMethod: string): void {
        this.invoicePDFModel.receiptionMethod = receiptionMethod;
    }

    show(group: any): void {
        let url = this.baseUrl + "/api/services/app/CarrierInvoice/GetCarrierInvoicePdf?id=" + group.carrierInvoice.id;
        this.invoicePdfUrl = this._sanitizer.bypassSecurityTrustResourceUrl(url);
        this.carrierInvoiceData = group;
        this.getBenefitTypesAndShowModal();
    }

    handleCallBack(): void {
        this.initializeModal(this.carrierInvoiceData);
        this.modal.show();
    }

    getBenefitTypesAndShowModal(): void {
        if (this.benefitTypes.length == 0) {
            this._benefitTypesService.getBenefitTypes().subscribe((res) => {
                this.benefitTypes = res.items;
                this.handleCallBack();
            });
        }
        else {
            this.handleCallBack();
        }

        this.modalElement = $(".carrier-invoice-pdf-modal .modal-content .modal-body");
        super.setScrollbar(this.modalElement, (window.innerHeight - 182 + 'px'));
    }

    //This event fires immediately when the show instance method is called. 
    //Occurs when the modal is about to be shown
    onShow(): void {
    }

    noInvoiceOnChange(event: any): void {

        let isChecked = event.target.checked;

        this.isInvoiceNumberRequired = !isChecked;

        if (isChecked) {

            $('#invoiceNumber').attr("disabled", "disabled");
            this.invoicePDFModel.invoiceNumber = 'N/A';
        }
        else {
            $('#invoiceNumber').removeAttr("disabled");
            this.invoicePDFModel.invoiceNumber = '';
        }
    }

    //Occurs when the modal is fully shown (after CSS transitions have completed)
    onModalShown(): void {
        this.iframeActive = true;
    }

    //coverageTypeOnChange(coverageType): void {

    //    let self = this;

    //    self.invoicePDFModel.coverageTypes = '';

    //    let checkedbenefitTypes = _.filter(this.benefitTypes, function (x: any) { return x.isChecked; });

    //    _.forEach(checkedbenefitTypes, function (x: any) {

    //        if (self.invoicePDFModel.coverageTypes.length === 0) {
    //            self.invoicePDFModel.coverageTypes = x.benefitType;
    //        }
    //        else {
    //            self.invoicePDFModel.coverageTypes = self.invoicePDFModel.coverageTypes + ', ' + x.benefitType;
    //        }
    //    });
    //}

    getCoverageMonths(): Array<any> {
        return [
            {
                "text": moment().add(-1, 'month').format('MMM'),
                "monthsToAdd": -1,
                "postfix": "",
                "style": { 'float': 'left', "font-style": "italic", "cursor": "pointer" }
            },
            {
                "text": moment().format('MMM'),
                "monthsToAdd": 0,
                "postfix": " (Current) ",
                "style": { 'text-align': 'center', 'margin-left': '32px', "font-style": "italic", "font-weight": "700", "cursor": "pointer" }
            },
            {
                "text": moment().add(1, 'month').format('MMM'),
                "postfix": "",
                "monthsToAdd": 1,
                "style": { 'float': 'right', "font-style": "italic", "cursor": "pointer" }
            }
        ]
    }

    coverageMonthOnChange(monthsToAdd: number): void {
        let month = moment().add(monthsToAdd, 'month').format('YYYY-MM');
        this.invoicePDFModel.coverageStartDate = month;
    }

    close(): void {
        this.modal.hide();
        this.iframeActive = false;
        super.destroyScrollbar(this.modalElement);
    }

    public chkNoInvoiceNumber: boolean = false;

    public isInvoiceNumberRequired: boolean = false;

    save(invoiceModel: any, form: any): void {

        if (!this.chkNoInvoiceNumber) {
            if (this.invoicePDFModel.invoiceNumber === '' || this.invoicePDFModel.invoiceNumber === null || this.invoicePDFModel.invoiceNumber === undefined) {
                this.isInvoiceNumberRequired = true;
                return;
            }
            else {
                this.isInvoiceNumberRequired = false;
            }
        }

        this.saving = true;

        this._carrierInvoiceService.updateInvoice(this.invoicePDFModel).finally(() => { this.saving = false; })
            .subscribe((res) => {
                this.iframeActive = false;
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(res);
            });
    }
}

export class InvoicePDFModel {
    constructor(
        public carrierInvoiceId: number,
        public invoiceFileName: string,
        public accountNumber: number,
        public isUrgent: boolean,
        public receivedVia: string,
        public coverageTypes: string = "",
        public totalInvoiceAmount?: number,
        public adjustmentAmount?: number,
        public dateReceived?: string,
        public coverageMonth?: string
    ) { }
}
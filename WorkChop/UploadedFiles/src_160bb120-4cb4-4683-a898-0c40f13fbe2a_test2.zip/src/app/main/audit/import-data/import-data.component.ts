import { Component, OnInit, Injector, ViewEncapsulation, ViewChild, AfterViewInit, EventEmitter, OnDestroy } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';
import { AppConsts } from '@shared/AppConsts';
import { Router } from '@angular/router';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { TokenService } from '@abp/auth/token.service';
import { FileUploader, FileUploaderOptions, Headers } from '@node_modules/ng2-file-upload';
import { IAjaxResponse } from '@abp/abpHttp';
import { CarrierInvoicePDFModalComponent } from './carrier-invoice-pdf-modal.component';
import { UserNotificationHelper, IFormattedUserNotification } from '@app/shared/layout/notifications/UserNotificationHelper';
import { NotificationServiceProxy, GetNotificationsOutput, UserNotification, FileUploadDto } from '@shared/service-proxies/service-proxies';
import { LocalStorageService } from '@shared/utils/local-storage.service';
import * as _ from "lodash";
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';

import {
    BenAdmin,
    Carrier,
    CarrierServiceProxy,
    Group,
    GroupServiceProxy,
    FileServiceProxy,
    CarrierInvoiceServiceProxy,
    CarrierInvoiceDto,
    ImportCarrierDataAppServiceProxy,
    ImportJobAppServiceProxy,
    TokenAuthServiceProxy
} from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './import-data.component.html',
    animations: [appModuleAnimation()],
    styleUrls: ['./import-data.component.css']
})

export class AuditImportDataComponent extends AppComponentBase implements AfterViewInit, OnInit {

    @ViewChild('carrierInvoicePdfModal') carrierInvoicePdfModal: CarrierInvoicePDFModalComponent;

    uniqueGroups: Group[] = [];
    benAdmins: BenAdmin[] = [];
    carriers: Carrier[] = [];
    groups: any = [];
    result: any = [];

    benAdminId: number;
    carrierId: number;
    groupId: number;

    loading: boolean = true;

    submitted: boolean = false;
    billMonths: Array<string> = [];

    importDataFilters = new ImportDataFilters(null, null, null, null);

    notifications: IFormattedUserNotification[] = [];
    unreadNotificationCount: number = 0;
    gridData = new Array<GridData>();
    private originalGridData = new Array<GridData>();
    private showGroupsRequiresImport: boolean = false;
    private sub: any;

    constructor(injector: Injector,
        private carrierService: CarrierServiceProxy,
        private groupService: GroupServiceProxy,
        private _tokenService: TokenService,
        private _fileService: FileServiceProxy,
        private _carrierInvoiceService: CarrierInvoiceServiceProxy,
        private _importCarrierDataAppServiceProxy: ImportCarrierDataAppServiceProxy,
        private _importJobAppServiceProxy: ImportJobAppServiceProxy,
        private _tokenAuthProxy: TokenAuthServiceProxy,
        private _userNotificationHelper: UserNotificationHelper,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private _notificationService: NotificationServiceProxy,
        private _storageService: LocalStorageService
    ) { super(injector); }

    ngOnDestroy(): void { this.unsubscribeToEvents(); }

    ngOnInit(): void {
        this._storageService.getItem('filters', (key, filters) => {
            this.loadImportDataFilters.call(this, filters);
        });

        this.subscribeToEvents();
    }

    loadImportDataFilters(filters): void {
        var filters = JSON.parse(filters);
        this.importDataFilters.benAdminId = filters.benAdminId;
        this.importDataFilters.carrierId = filters.carrierId;
        this.importDataFilters.groupId = filters.groupId;
        this.importDataFilters.billingMonth = filters.billingMonth;
        this.loadImportCarrierData(this.importDataFilters.benAdminId);
    }

    loadImportCarrierData(benAdminId): void {
        var self_ = this;

        this.getBillMonths();

        abp.ui.setBusy();

        //load import data filters
        this._importCarrierDataAppServiceProxy.loadImportCarrierDataFilters(benAdminId).subscribe((res) => {

            let _self = this;

            this.benAdmins = res.benAdmins.items;

            var defaultCarrier = new Carrier();

            defaultCarrier.carrierName = "No Carrier(s) Available";

            defaultCarrier.id = 0;

            this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

            this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

            _.forEach(res.groups.items, function (x) {
                _self.groups.push(x);
            })

            this.benAdminId = this.importDataFilters.benAdminId = this.importDataFilters.benAdminId > 0 ? this.importDataFilters.benAdminId : this.benAdmins[0].id;

            this.groupId = this.importDataFilters.groupId = this.importDataFilters.groupId > 0 ? this.importDataFilters.groupId : this.groups[0].id;

            this.carrierId = this.importDataFilters.carrierId = this.importDataFilters.carrierId > 0 ? this.importDataFilters.carrierId : this.carriers[0].id;

            let currentMonthIndex = moment().format('M');

            this.importDataFilters.billingMonth = this.importDataFilters.billingMonth != undefined ? this.importDataFilters.billingMonth : this.billMonths[+currentMonthIndex - 1];

            this.getFilteredDataBasedOnSelectedFilters(this.benAdminId, this.carrierId, this.groupId, this.importDataFilters.billingMonth);

            this.setFiltersForReuse();
        })
    }

    unsubscribeToEvents(): void {
        jQuery("body").off('drag dragstart dragend dragleave dragenter dragover drop', function (e) {
            let event = e;
            event.preventDefault();
            event.stopPropagation();
            event.originalEvent.preventDefault();
            event.originalEvent.stopPropagation();
        });
    }

    loadNotifications(): void {
        this._notificationService.getUserNotifications(undefined, 3, undefined).subscribe(result => {
            this.unreadNotificationCount = result.unreadCount;
            this.notifications = [];
            $.each(result.items, (index, item: UserNotification) => {
                this.notifications.push(this._userNotificationHelper.format(<any>item));
            });
        });
    }

    showGroupsRequiresImportOnChange(value: boolean): void {
        abp.ui.setBusy();
        this.getFilteredDataBasedOnSelectedFilters(this.benAdminId, this.carrierId, this.groupId, this.importDataFilters.billingMonth);
    }

    subscribeToEvents(): void {

        //if file was dragged over to the body         
        //then we don't allow the drag and drop event
        //otherwise browser will display the content of the file
        jQuery("body").on('drag dragstart dragend dragleave dragenter dragover drop', function (e) {
            let event = e;
            event.preventDefault();
            event.stopPropagation();
            event.originalEvent.preventDefault();
            event.originalEvent.stopPropagation();
        });

        abp.event.on("abp.notifications.received.carriercsv.import.started", notificationData => {
            this._userNotificationHelper.show(notificationData);
            abp.event.trigger('app.notifications.refresh');
        });

        abp.event.on("abp.notifications.received.carriercsv.import.successful", notificationData => {
            this._userNotificationHelper.show(notificationData);
            abp.event.trigger('app.notifications.refresh');

            let self = this;

            let groupsThatHasCarrierGroups = self.gridData.filter(x => x.carrierGroupsAccount !== undefined && x.carrierGroupsAccount.length > 0);

            let notificationProps = notificationData.notification.data.properties;

            let groupWithCsvImportIdMatchingWithGivenId = null, gridDataRow = null;

            for (let i = 0; i < groupsThatHasCarrierGroups.length; i++) {

                var groupAccount = _.find(groupsThatHasCarrierGroups[i].carrierGroupsAccount, function (o: any) {
                    return (
                        o.carrierCSV !== null
                        && o.carrierCSV !== undefined
                        && o.carrierCSV.id === notificationProps.importJobId);
                });

                if (groupAccount !== null && groupAccount !== undefined) {
                    groupWithCsvImportIdMatchingWithGivenId = groupAccount.carrierCSV;
                    gridDataRow = groupsThatHasCarrierGroups[i];
                    break;
                }
            }

            groupWithCsvImportIdMatchingWithGivenId.isCsvAvailable = notificationProps.isCsvAvailable;
            groupWithCsvImportIdMatchingWithGivenId.totalPremium = notificationProps.totalPremium;

            //if invoice PDF is available then only match the amount otherwise do nothing
            if (groupAccount.carrierInvoice !== null && groupAccount.carrierInvoice.isPDFAvailable) {
                this.matchTotalPremium(gridDataRow);
            }
        });

        abp.event.on("abp.notifications.received.carriercsv.import.failed", notificationData => {
            this._userNotificationHelper.show(notificationData);
        });
    };

    //to match the premium columns of both the CSV and PDF's
    matchTotalPremium(gridDataRow: any): void {

        var carrierGroupsAccount = _.filter(gridDataRow.carrierGroupsAccount, function (x: any) {
            return x.carrierCSV !== null && x.carrierInvoice !== null
        });

        for (let i = 0; i < carrierGroupsAccount.length; i++) {

            let carrierCSV = carrierGroupsAccount[i].carrierCSV;
            let carrierInvoice = carrierGroupsAccount[i].carrierInvoice;

            if (carrierCSV.isCsvAvailable && carrierInvoice.isPDFAvailable) {

                let _csvTotalPremium = parseFloat(carrierCSV.totalPremium);

                let _pdfTotalPremium = parseFloat(carrierInvoice.totalPremiumAmount);

                let areAmountsEqual: boolean = _csvTotalPremium === _pdfTotalPremium;

                gridDataRow.areTotalPremiumEquals = areAmountsEqual;

                if (!gridDataRow.areTotalPremiumEquals) {
                    break;
                }
            }
            else {
                gridDataRow.areTotalPremiumEquals = true;
            }
        };
    }

    ngAfterViewInit(): void {


    };

    //sets the filters in local forage so that we can access them across different components
    setFiltersForReuse(): void {
        this._storageService.setItem('filters', JSON.stringify(this.importDataFilters));
    }

    //this will redirect to ResolveNameMismatchComponent
    redirectToResolveNameMismatchComponent(): void {
        this.router.navigate(['app/main/audit/resolve-name-mismatches']);
    }

    //this will redirect to ReviewInvoicesComponent
    redirectToReviewInvoiceComponent(): void {
        this.router.navigate(['app/main/audit/review-invoices']);
    }

    getFilteredDataBasedOnSelectedFilters(benAdminId: number, carrierId: number, groupId: any, billingMonth: string): void {

        this.gridData = []; let finalGroups = null;

        //this will load the selected filters data
        this._importCarrierDataAppServiceProxy.getAppliedFiltersData(benAdminId, carrierId, groupId, billingMonth)
            .finally(function () { this.loading = false; abp.ui.clearBusy(); })
            .subscribe((res) => {

                let self = this;

                let response = res.data;

                _.forEach(response, function (data, index) {

                    _.forEach(data.groups, function (responseGroup) {

                        //find each groups in total available groups
                        var matchedGroup = _.find(self.groups, function (x: any) { return x.id === responseGroup.id; });

                        if (matchedGroup !== undefined) {
                            matchedGroup.carrierGroupsAccount = data.carrierGroupsAccount;
                            matchedGroup.carrierUrl = data.carrierUrl;
                        }
                    });
                });

                //This means All is selected in the Groups dropdown
                if (self.importDataFilters.groupId === 0) {
                    finalGroups = _.filter(self.groups, function (x: any) { return x.id !== self.importDataFilters.groupId });
                }
                else {
                    //get only the group data that is currently selected in the dropdown
                    finalGroups = _.filter(self.groups, function (x: any) { return x.id == self.importDataFilters.groupId });
                }

                if (response.length > 0) {

                    this.initializeGridData(finalGroups);

                    if (this.gridData.length > 0) {

                        //match total premium with the CSV and PDF's for each imported CSV
                        _.forEach(this.gridData, function (x: any) {
                            if (x.carrierGroupsAccount !== null && x.carrierGroupsAccount !== undefined && x.carrierGroupsAccount.length !== 0) {
                                self.matchTotalPremium(x);
                            }
                        });
                    }

                    this.checkIfShowGroupsRequiresImportOptionCheckedAndShowDataAccordingly(this.showGroupsRequiresImport);
                }
            });
    }

    checkIfShowGroupsRequiresImportOptionCheckedAndShowDataAccordingly(isChecked: boolean): void {

        if (isChecked) {

            let result = [];

            _.forEach(this.gridData, function (x: any) {

                var groupAccounts = _.find(x.carrierGroupsAccount, function (y: any) {
                    return y.carrierCSV === null || y.carrierInvoice == null ||
                        (y.carrierCSV !== null && y.carrierCSV.isCsvAvailable === false);
                });

                if (groupAccounts !== undefined) {
                    result.push(x);
                }
            });

            this.originalGridData = this.gridData;

            this.gridData = result;
        }
        else {
            this.gridData = this.originalGridData.length === 0 ? this.gridData : this.originalGridData;
        }
    }

    initializeGridData(data: any): void {

        let _self = this;

        this.gridData = [];

        //add grid rows
        for (let i = 0; i < data.length; i++) {
            this.gridData.push(new GridData(data[i].id, data[i].employerName, data[i].carrierUrl, data[i].carrierGroupsAccount));
        }

        //add pdf file uploader for each row if there is any
        //select carrier group fro whihc we need to define PDF uploader
        //for each carrier group there should be separate PDF uploader
        let result = this.gridData.filter(x => x.carrierGroupsAccount !== undefined && x.carrierGroupsAccount.length > 0);

        for (let i = 0; i < result.length; i++) {
            let group = result[i].carrierGroupsAccount;
            for (let j = 0; j < group.length; j++) {
                this.attachCSVUploaderEvents(group[j]);
                this.attachPdfUploaderEvents(group[j]);
            }
        }
    }

    attachCSVUploaderEvents(data: any): void {

        let self_ = this;

        let carrierInvoiceNumber = data.carrierInvoice !== null ? data.carrierInvoice.invoiceNumber : null;

        let csvUploadUrl = AppConsts.remoteServiceBaseUrl + "/File/UploadCsvFile?clientCarrierId=" + data.clientCarrierId
            + "&carrierGroupAccountId=" + data.id;

        data.carrierCSV = data.carrierCSV === null ? {} : data.carrierCSV;

        data.carrierCSV.isCsvAvailable = Object.keys(data.carrierCSV).length > 0 ? true : false;

        data.csvUploader = new FileUploader({
            url: csvUploadUrl,
            filters: [{
                name: 'extension',
                fn: (item: any): boolean => {
                    const fileExtension = item.name.slice(item.name.lastIndexOf('.') + 1).toLowerCase();
                    return fileExtension === 'csv';
                }
            }]
        });

        this.initFileUploaderOptions(data.csvUploader);

        data.carrierCSV.isCSVUploading = false;
        data.hasCsvBaseDropZoneOver = false;

        //when PDF file is over the drag and drop zone
        data.csvFileOverBase = function (event, rawData) {
            rawData.hasCsvBaseDropZoneOver = event;
        };

        data.csvFileDropped = function (e, rawData) {
            rawData.carrierCSV.isCSVUploading = true;
        };

        data.csvUploader.onBuildItemForm = (item, form) => {
            //add billing month in the URL for CSV uploading
            item.url += "&billingMonth=" + self_.importDataFilters.billingMonth;
        };

        data.csvUploader.onAfterAddingFile = (file) => {
            data.carrierCSV.isCSVUploading = true;
            file.withCredentials = false;
            abp.ui.setBusy();
        };

        data.csvUploader.onWhenAddingFileFailed = (file) => {
            abp.ui.clearBusy();
            this.notify.warn("Please select a valid CSV file.");
        };

        data.csvUploader.onSuccessItem = (item, response, status) => {

            abp.ui.clearBusy();

            let resp = <IAjaxResponse>JSON.parse(response);

            data.carrierCSV.isCSVUploading = false;

            if (resp.success) {
                data.carrierCSV.id = resp.result.csvJob.id;
            }
            else {
                this.message.error(resp.error.message);
            }
        };

        data.csvUploader.onErrorItem = (item, response, status) => {
            data.isCSVUploading = false;
        }
    }

    //Attach PDF uploader events
    attachPdfUploaderEvents(group: any): void {

        let pdfUploadUrl = AppConsts.remoteServiceBaseUrl + "/File/UploadCarrierInvoicePDF?carrierGroupAccountId=" + group.id + "&billingMonthYear=" + this.importDataFilters.billingMonth;

        group.pdfUploader = new FileUploader({ url: pdfUploadUrl, allowedMimeType: ['application/pdf'] });

        this.initFileUploaderOptions(group.pdfUploader);

        //group.carrierInvoice = group.carrierInvoice === null ? {} : group.carrierInvoice;

        group.hasPdfBaseDropZoneOver = false;

        group.isPdfUploading = false;

        //when PDF file is over the drag and drop zone
        group.pdfFileOverBase = function (event, carrierGroup) {
            carrierGroup.hasPdfBaseDropZoneOver = event;
        }

        group.pdfFileDropped = function (e, carrierGroup) {
            carrierGroup.isPdfUploading = true;
        }

        group.pdfUploader.onAfterAddingFile = (file) => {
            file.withCredentials = false;
        };

        group.pdfUploader.onWhenAddingFileFailed = (file) => {
            group.isPdfUploading = false;
            this.notify.warn("Please select a valid PDF file.");
        }

        group.pdfUploader.onSuccessItem = (item, response, status) => {

            abp.ui.setBusy();

            let resp = <IAjaxResponse>JSON.parse(response);

            if (resp.success) {

                let fileUploadDto = new FileUploadDto();

                fileUploadDto.tempFilePath = resp.result.tempFilePath;
                fileUploadDto.fileName = resp.result.fileName;
                fileUploadDto.carrierGroupAccountId = resp.result.carrierGroupAccountId;
                fileUploadDto.billingMonthYear = resp.result.billingMonthYear;

                this._fileService.saveCarrierInvoice(fileUploadDto).finally(function () { abp.ui.clearBusy(); })
                    .subscribe((res) => {

                        let response = res._body;

                        let groupAccount = null; let gridData = null;

                        _.find(this.gridData, function (x: any) {

                            var account = _.find(x.carrierGroupsAccount, function (o: any) {
                                return +o.id === response.carrierGroupAccountId;
                            });

                            if (account !== undefined) {

                                account.isPDFAvailable = true;
                                account.isUploaded = true;

                                //if new then assign the data
                                if (account.carrierInvoice === null) {
                                    account.carrierInvoice = response;
                                }
                                //otherwise update it
                                else {
                                    _.assign(account.carrierInvoice, response);
                                }

                                gridData = x;
                                gridData.areTotalPremiumEquals = null;
                                groupAccount = account;
                                groupAccount.isPdfUploading = false;
                            }
                        });

                        groupAccount.billingMonth = this.importDataFilters.billingMonth;

                        if (groupAccount !== null) {
                            this.carrierInvoicePdfModal.show(groupAccount);
                        }

                        //if carrier csv is available for this group account for whihc PDF invoice has been uploaded
                        //then match the amounts
                        if (groupAccount.carrierCSV !== null && groupAccount.carrierCSV.isCsvAvailable) {
                            this.matchTotalPremium(gridData);
                        }
                    });
            }
            else {
                this.message.error(resp.error.message);
            }
        };

        group.pdfUploader.onErrorItem = (item, response, status) => {
            abp.ui.clearBusy();
            let resp = <IAjaxResponse>JSON.parse(response);
            this.message.error(resp.error.message);
        };
    };

    onCarrierInvoiceModalSaved(data: CarrierInvoiceDto): void {

        let gridData = null, groupAccount = null;

        var res = _.find(this.gridData, function (x: any) {

            var account = _.find(x.carrierGroupsAccount, function (o: any) {
                return +o.id === data.carrierGroupAccountId;
            });

            if (account !== undefined) {

                account.isPDFAvailable = true;

                account.isUploaded = true;

                //if new then assign the data
                if (account.carrierInvoice === null) {
                    account.carrierInvoice = data;
                }
                //otherwise update it
                else {
                    _.assign(account.carrierInvoice, data);
                }

                gridData = x;
                groupAccount = account;
            }
        });

        //match the premium amounts for the same group acocunt for the carrier CSV
        if (groupAccount.carrierCSV !== null && groupAccount.carrierCSV.isCsvAvailable) {
            this.matchTotalPremium(gridData);
        }
    }

    initFileUploaderOptions(uploader: FileUploader): void {

        let self = this;

        uploader.options.autoUpload = true;

        uploader.options.authToken = 'Bearer ' + self._tokenService.getToken();

        uploader.options.removeAfterUpload = false;

        uploader.setOptions(uploader.options);
    }

    private getBillMonths(): void {

        let currentYear = new Date().getFullYear();

        let monthArray = moment.monthsShort();

        for (let i = 0; i < monthArray.length; i++) {
            this.billMonths.push(monthArray[i] + ', ' + currentYear);
        }
    };

    benAdminOnChange(newValue): void {

        abp.ui.setBusy();

        this.importDataFilters.benAdminId = newValue;

        this._importCarrierDataAppServiceProxy.loadImportCarrierDataFilters(this.importDataFilters.benAdminId).finally(function () { abp.ui.clearBusy(); })
            .subscribe((res) => {

                let this_ = this;

                var defaultCarrier = new Carrier();
                defaultCarrier.carrierName = "No Carrier(s) Available";
                defaultCarrier.id = 0;

                this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

                this.groups = [];

                this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

                _.forEach(res.groups.items, function (x) {
                    this_.groups.push(x);
                })

                this.groupId = this.importDataFilters.groupId = this.groups[0].id;
                this.carrierId = this.importDataFilters.carrierId = this.carriers.length > 0 ? this.carriers[0].id : defaultCarrier.id;

                this.setFiltersForReuse();
            });
        
    };

    billingMonthOnChange(newValue: string): void {
        this.importDataFilters.billingMonth = newValue;
        this.setFiltersForReuse();
    }

    carrierOnChange(newVal): void {
        this.importDataFilters.carrierId = newVal;
        this.setFiltersForReuse();
    }

    groupOnChange(groupId: number): void {
        this.importDataFilters.groupId = groupId;
        this.setFiltersForReuse();
    };

    //submit event of form
    onRefreshClick(event: any) {
        abp.ui.setBusy();
        this.carrierId = this.importDataFilters.carrierId;
        this.groupId = this.importDataFilters.groupId;
        this.benAdminId = this.importDataFilters.benAdminId;
        this.getFilteredDataBasedOnSelectedFilters(this.benAdminId, this.carrierId, this.groupId, this.importDataFilters.billingMonth);
    }

    deleteInvoicePDF(data: any, gridData: any): void {

        if (data.id === undefined || data.carrierGroupAccountId === undefined
            || data.id === null
            || data.carrierGroupAccountId === null) {
            this.notify.error("Unable to delete the invoice PDF. Please refresh the page and try again later.");
            return;
        }

        this.message.confirm("Are you sure you want to delete the invoice PDF?", isConfirmed => {

            if (isConfirmed) {

                abp.ui.setBusy();

                this._carrierInvoiceService.deleteInvoice(data.carrierGroupAccountId, data.id).finally(function () { abp.ui.clearBusy(); }).subscribe((res) => {

                    //means success
                    if (res === null) {

                        gridData.areTotalPremiumEquals = null;

                        this.notify.success("Invoice deleted successfully.");

                        _.filter(this.groups, function (group: any) {

                            var group = _.find(group.carrierGroupsAccount, function (x: any) {
                                return +x.id === data.carrierGroupAccountId;
                            })

                            if (group !== undefined) {
                                group.carrierInvoice = null;
                            }
                        });
                    }
                    else {
                        this.notify.error("Unable to delete the invoice PDF. Please refresh the page and try again later.");
                    }
                });
            }
        });
    }

    deleteCSV(group: any, gridData: any): void {

        let importJobId = group.carrierCSV["id"];

        if (importJobId === undefined || importJobId === null) {
            this.notify.error("Unable to delete CSV. Please refresh the page and try again later.");
            return;
        }

        this.message.confirm("Are you sure you want to delete the CSV?", isConfirmed => {

            if (isConfirmed) {

                abp.ui.setBusy();

                this._importJobAppServiceProxy.deleteJob(importJobId).finally(function () { abp.ui.clearBusy(); }).subscribe((deletedRecordCount) => {

                    if (deletedRecordCount > 0) {
                        gridData.areTotalPremiumEquals = null;
                        group.carrierCSV.isCsvAvailable = false;
                        group.carrierCSV.isCSVUploading = false;
                        group.carrierCSV.totalPremium = null;
                        this.notify.success("CSV deleted successfully.");
                    }
                    else {
                        this.notify.error("Unable to delete CSV. Please refresh the page and try again later.");
                    }
                });
            }
        });
    }

    viewCarrierInvoicePDF(group: any): void {

        if (group.carrierInvoice === null || group.carrierInvoice === undefined) { return; }

        //if PDF is available then only show the PDF Invoice Modal        
        if (group.carrierInvoice.isPDFAvailable) {
            group.billingMonth = this.importDataFilters.billingMonth;
            this.carrierInvoicePdfModal.show(group);
        }
    }
}

export class ImportDataFilters {
    constructor(
        public benAdminId?: number,
        public billingMonth?: string,
        public carrierId?: number,
        public groupId?: number
    ) { }

    equals(objectToCompare: ImportDataFilters): boolean {
        if (objectToCompare.benAdminId === this.benAdminId && objectToCompare.billingMonth === this.billingMonth && objectToCompare.carrierId === this.carrierId && objectToCompare.groupId === this.groupId) {
            return true;
        }
    }
}

export class GridData {
    constructor(
        public groupId: number,
        public groupName: string,
        public carrierUrl: string,
        public carrierGroupsAccount: any
    ) { }
}
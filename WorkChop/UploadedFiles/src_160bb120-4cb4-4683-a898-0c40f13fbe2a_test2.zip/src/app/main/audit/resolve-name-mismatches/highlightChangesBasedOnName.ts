﻿import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';
import * as _ from "lodash";

@Directive({
    selector: "[highlightChangesBasedOnName]"
})

//This directive will check the differences between the first name and last name i.e. received from 
//ben admin and carrier and then show the differences in red colour on UI
export class HighlightChangesBasedOnName implements AfterViewInit {

    @Input() benAdminData: any = null;

    @Input() carrierData: any = null;

    private dom: any = null;

    constructor(
        private _element: ElementRef
    ) { this.dom = _element.nativeElement }


    ngAfterViewInit(): void {

        let firstNameReceivedFromBenAdmin: string = this.benAdminData.firstName;
        let firstNameReceivedFromCarrier: string = this.carrierData.firstName;
        let lastNameReceivedFromBenAdmin: string = this.benAdminData.lastName;
        let lastNameReceivedFromCarrier: string = this.carrierData.lastName;

        if (firstNameReceivedFromBenAdmin.toLowerCase() === firstNameReceivedFromCarrier.toLowerCase()
            && lastNameReceivedFromBenAdmin.toLowerCase() === lastNameReceivedFromCarrier.toLowerCase()) {
            this.dom.innerHTML = '<span>' + firstNameReceivedFromBenAdmin + ', ' + lastNameReceivedFromBenAdmin + '</span>';

        } else if (firstNameReceivedFromBenAdmin.toLowerCase() !== firstNameReceivedFromCarrier.toLowerCase()
            && lastNameReceivedFromBenAdmin.toLowerCase() === lastNameReceivedFromCarrier.toLowerCase()) {
            let name = this.highlightName(firstNameReceivedFromCarrier, firstNameReceivedFromBenAdmin);
            this.dom.innerHTML = '<span>' + name + ', ' + lastNameReceivedFromBenAdmin + '</span>';
        }
        else if (firstNameReceivedFromBenAdmin.toLowerCase() === firstNameReceivedFromCarrier.toLowerCase()
            && lastNameReceivedFromBenAdmin.toLowerCase() !== lastNameReceivedFromCarrier.toLowerCase()) {
            let name = this.highlightName(lastNameReceivedFromCarrier, lastNameReceivedFromBenAdmin);
            this.dom.innerHTML = '<span>' + firstNameReceivedFromBenAdmin + ', ' + name + '</span>';
        }
        else if (firstNameReceivedFromBenAdmin.toLowerCase() !== firstNameReceivedFromCarrier.toLowerCase()
            && lastNameReceivedFromBenAdmin.toLowerCase() !== lastNameReceivedFromCarrier.toLowerCase()) {
            let firstName = this.highlightName(firstNameReceivedFromCarrier, firstNameReceivedFromBenAdmin);
            let lastName: string = this.highlightName(lastNameReceivedFromCarrier, lastNameReceivedFromBenAdmin);
            this.dom.innerHTML = firstName + ', ' + lastName;
        }
    }

    highlightName(nameReceivedFromCarrier: string, nameReceivedFromBenAdmin): string {

        let result = null;

        let differenceInCarrierName = _.difference(nameReceivedFromCarrier.split(''), nameReceivedFromBenAdmin.split(''));

        if (differenceInCarrierName.length > 0) {

            for (let i: number = 0; i < differenceInCarrierName.length; i++) {

                var index = nameReceivedFromCarrier.indexOf(differenceInCarrierName[i]);

                if (index > -1) {

                    let firstNamesCharactersArray: Array<string> = nameReceivedFromCarrier.split('');

                    _.remove(firstNamesCharactersArray, function (n: any) {
                        return n == differenceInCarrierName[i];
                    });

                    firstNamesCharactersArray.splice(index, 0, '<span style="color: red;">' + differenceInCarrierName[i] + '</span>');

                    result = firstNamesCharactersArray.join('');
                }
            }
        }

        return result;
    }
}
﻿import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';
import * as _ from "lodash";

@Directive({
    selector: "[highlightChangesBasedOnSSN]"
})

//This directive will check the differences between the first name and last name i.e. received from 
//ben admin and carrier and then show the differences in red colour on UI
export class HighlightChangesBasedOnSSN implements AfterViewInit {

    @Input() benAdminData: any = null;

    @Input() carrierData: any = null;

    private dom: any = null;

    constructor(
        private _element: ElementRef
    ) { this.dom = _element.nativeElement }


    ngAfterViewInit(): void {

        let ssnReceivedFromBenAdmin: string = this.benAdminData.ssn;

        let ssnReceivedFromCarrier: string = this.carrierData.ssn;

        if (ssnReceivedFromCarrier === null || ssnReceivedFromCarrier === undefined) { return; }

        if (ssnReceivedFromBenAdmin !== ssnReceivedFromCarrier) {

            let digitsThatHaveChanges = _.difference(ssnReceivedFromCarrier.split(''), ssnReceivedFromBenAdmin.split(''));

            if (digitsThatHaveChanges.length === 0) { return; }

            let result = [];

            _.forEach(ssnReceivedFromBenAdmin, function (benAdminSSNDigit: string, outerIndex: number) {
                let digitsFromCarrierSSN = ssnReceivedFromCarrier[outerIndex];
                if (digitsFromCarrierSSN !== benAdminSSNDigit) {
                    let splittedSSN = ssnReceivedFromCarrier.split('');
                    splittedSSN.splice(outerIndex, 1, "<span style='color: red'>" + digitsFromCarrierSSN + "</span>");
                    result.push(splittedSSN[outerIndex]);
                }
                else {
                    result.push(digitsFromCarrierSSN);
                }
            });

            if (result.length === 9) {
                let firstSegment = result.slice(0, 3);
                let secondSegment = result.slice(3, 5);
                var thirdSegment = result.slice(5, 9);
                this.dom.innerHTML = 'SSN: ' + firstSegment.join('') + "-" + secondSegment.join('') + '-' + thirdSegment.join('');
            }
        }
        else {
            this.dom.innerHTML = 'SSN: ' + this.formatSSN(ssnReceivedFromBenAdmin);
        }
    }

    formatSSN(value: string): string {
        if (value.length === 9) {
            let firstSegment = value.slice(0, 3);
            let secondSegment = value.slice(3, 5);
            var thirdSegment = value.slice(5, 9);
            value = firstSegment + "-" + secondSegment + '-' + thirdSegment;
        }
        return value;
    }
}
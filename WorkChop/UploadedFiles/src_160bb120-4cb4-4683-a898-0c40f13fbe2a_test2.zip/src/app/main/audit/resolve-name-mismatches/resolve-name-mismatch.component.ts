﻿import { Component, OnInit, Injector, ViewEncapsulation, ViewChild, AfterViewInit, OnDestroy, Pipe, PipeTransform } from '@angular/core';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute } from '@angular/router';
import { ModalDirective } from 'ng2-bootstrap';
import { AppConsts } from '@shared/AppConsts';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { TokenService } from '@abp/auth/token.service';
import { ImportDataFilters } from '../import-data/import-data.component';
import { FileUploader, FileUploaderOptions, Headers } from '@node_modules/ng2-file-upload';
import { IAjaxResponse } from '@abp/abpHttp';
import * as _ from "lodash";
import * as moment from 'moment';
import { LocalStorageService } from '@shared/utils/local-storage.service';

import {
    BenAdmin,
    Carrier,
    CarrierServiceProxy,
    Group,
    GroupServiceProxy,
    FileServiceProxy,
    CarrierInvoiceServiceProxy,
    CarrierInvoiceDto,
    ImportCarrierDataAppServiceProxy,
    ResolveNameMismatchServiceProxy,
    SubscriberAppServiceProxy,
    DiscrepancyServiceProxy,
    MatchInputDto,
    SubscriberSearchDto
} from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './resolve-name-mismatch.component.html',
    animations: [appModuleAnimation()],
    styleUrls: ['./resolve-name-mismatch.component.css']
})

export class ResolveNameMismatchComponent extends AppComponentBase implements OnInit, AfterViewInit {

    private benAdmins: BenAdmin[] = [];
    private carriers: Carrier[] = [];
    private groups: any = [];
    private billMonths: Array<string> = [];
    private filters = new ImportDataFilters(null, null, null, null);
    private sub: any;
    private benAdminId: number;
    private groupId: number;
    private carrierId: number;
    private exactPotentialMatches: any = [];
    private automaticMatches: any = [];
    private manualMatches: any = [];
    private exactPotentialMatchesDataLoading: boolean = true;
    public selectedBenAdminEmployee: string;
    public dataSource: Observable<any>;

    constructor(injector: Injector,
        private carrierService: CarrierServiceProxy,
        private groupService: GroupServiceProxy,
        private _tokenService: TokenService,
        private _fileService: FileServiceProxy,
        private _carrierInvoiceService: CarrierInvoiceServiceProxy,
        private _importCarrierDataAppServiceProxy: ImportCarrierDataAppServiceProxy,
        private route: ActivatedRoute,
        private _resolveNameMismatchService: ResolveNameMismatchServiceProxy,
        private _subscriberService: SubscriberAppServiceProxy,
        private _discrepancyService: DiscrepancyServiceProxy,
        private _storageService: LocalStorageService
    ) {
        super(injector);

        // typeahead data source
        this.dataSource = Observable.create((observer: any) => {

            let searchDto = new SubscriberSearchDto();
            searchDto.carrierId = this.filters.carrierId;
            searchDto.clientId = this.filters.groupId;
            searchDto.billingMonth = this.filters.billingMonth;
            searchDto.query = observer.outerValue;

            this._subscriberService.findSubscribers(searchDto).subscribe((result: any) => {
                observer.next(result);
            });
        });
    }

    changeTypeaheadLoading(e: boolean, match: any): void {
        match[0].typeaheadLoading = e;
    }

    typeaheadOnSelect(selectedTypeheadValue: any, match: any): void {
        match[1] = selectedTypeheadValue.item;
        match[0].selectedBenAdminEmployee = null;
    }

    ngOnDestroy(): void {
    }

    benAdminEmployeeOnChange(selected: string): void { }

    //reject the system accepted matches from 3rd bucket
    rejectSystemAcceptedMatches(benAdminData: any, carrierData: any): void {

        let input = new MatchInputDto();
        input.importedDataId = carrierData.importedDataId;
        input.employmentId = benAdminData.employmentId;
        input.coverageId = benAdminData.coverageId;
        input.benAdminMonthlyPremiumId = benAdminData.benAdminMonthlyPremiumId;
        input.addressingMonth = this.filters.billingMonth;

        this._discrepancyService.isDiscrepancyStatusOpen(input).subscribe((discrepancyStatus) => {

            //if discrepancyStatus is not open then alert the user that the Audit status will be reset
            if (!discrepancyStatus) {

                this.message.confirm("The Audit status will be reset. Are you sure you want to continue?", isConfirmed => {

                    if (isConfirmed) {

                        abp.ui.setBusy();

                        this.afterDiscrepancyStatusCheckCallBack(input);
                    }
                });
            }
            else {

                abp.ui.setBusy();

                this.afterDiscrepancyStatusCheckCallBack(input);
            }
        });
    }

    //this function will get called afte the discrepancy status had been checked
    afterDiscrepancyStatusCheckCallBack(input: MatchInputDto): void {
        this._resolveNameMismatchService.rejectSystemAcceptedMatch(input).finally(function () { abp.ui.clearBusy() }).subscribe((response) => {
            this.loadMismatches();
        });
    }

    rejectPotentialMatch(benAdminData: any, carrierData: any): void {

        abp.ui.setBusy();
        let input = new MatchInputDto();
        input.importedDataId = carrierData.importedDataId;
        input.employmentId = benAdminData.employmentId;
        input.coverageId = benAdminData.coverageId;
        input.benAdminMonthlyPremiumId = benAdminData.benAdminMonthlyPremiumId;
        input.addressingMonth = this.filters.billingMonth;

        this._resolveNameMismatchService.rejectPotentialMatch(input)
            .finally(function () { abp.ui.clearBusy() }).subscribe((res) => {
                this.loadMismatches();
            });
    }

    acceptMatch(benAdminData: any, importedDataId: number): void {

        abp.ui.setBusy();
        let input = new MatchInputDto();
        input.benAdminMonthlyPremiumId = benAdminData.benAdminMonthlyPremiumId;
        input.employmentId = benAdminData.employmentId;
        input.importedDataId = importedDataId;
        input.coverageId = benAdminData.coverageId;
        input.addressingMonth = this.filters.billingMonth;

        this._resolveNameMismatchService.acceptMatch(input)
            .finally(function () { abp.ui.clearBusy() }).subscribe((res) => {
                this.loadMismatches();
            });
    }

    ngOnInit(): void {

        this._storageService.getItem('filters', (key, filters) => {
            this.loadImportDataFilters.call(this, filters);
        });
    }


    loadImportDataFilters(filters): void {
        var filters = JSON.parse(filters);
        this.filters.benAdminId = filters.benAdminId;
        this.filters.carrierId = filters.carrierId;
        this.filters.groupId = filters.groupId;
        this.filters.billingMonth = filters.billingMonth;
        this.loadMismatchesData(this.filters.benAdminId);
    }

    loadMismatchesData(benAdminId): void {
        abp.ui.setBusy();

        var self = this;

        this.getBillMonths();

        //load import data filters
        this._importCarrierDataAppServiceProxy.loadImportCarrierDataFilters(benAdminId).subscribe((res) => {

            let this_ = this;

            var defaultCarrier = new Carrier();
            defaultCarrier.carrierName = "No Carrier(s) Available";
            defaultCarrier.id = 0;

            this.benAdmins = res.benAdmins.items;

            this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

            this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroups: [] }));

            _.forEach(res.groups.items, function (x) {
                this_.groups.push(x);
            })

            this.benAdminId = this.filters.benAdminId = this.filters.benAdminId > 0 ? this.filters.benAdminId : this.benAdmins[0].id;
            this.groupId = this.filters.groupId = this.filters.groupId > 0 ? this.filters.groupId : this.groups[0].id;
            this.carrierId = this.filters.carrierId = this.filters.carrierId > 0 ? this.filters.carrierId : this.carriers[0].id;

            this.loadMismatches();
        })
    }

    ngAfterViewInit(): void {


    }

    //This is used to load the mismatches data into the tables
    loadMismatches(): void {

        this._resolveNameMismatchService.getMismatchesData(this.benAdminId, this.groupId, this.carrierId, this.filters.billingMonth)
            .finally(function () { abp.ui.clearBusy(); this.exactPotentialMatchesDataLoading = false }).subscribe((res) => {
                this.exactPotentialMatches = res.potentialMatches;
                this.transformManualMatches(res.manualMatches);
                this.automaticMatches = res.automaticMatches;
            });
    }

    transformManualMatches(manualMatches: any): void {

        let result = [];

        _.forEach(manualMatches, function (data: any, index: number) {
            result.push([data, null]);
        });

        this.manualMatches = result;
    }

    formatBenAdminPremium(value: string): string {
        return 'BenAdmin Premium: $' + parseFloat(value).toFixed(2);
    }

    formatCarrierPremium(value: string): string {
        return 'Carrier Premium: $' + parseFloat(value).toFixed(2);
    }

    groupOnChange(groupId: number): void {
        this.filters.groupId = groupId;
        this.setFiltersForReuse();
    }

    carrierOnChange(carrierId: number): void {
        this.filters.carrierId = carrierId;
        this.setFiltersForReuse();
    }

    billingMonthOnChange(billingMonth: string): void {
        this.filters.billingMonth = billingMonth;
        this.setFiltersForReuse();
    }

    formatSSN(value: string): string {

        if (value === null || value === undefined) {
            return value;
        }

        if (value.length === 9) {
            let firstSegment = value.slice(0, 3);
            let secondSegment = value.slice(3, 5);
            var thirdSegment = value.slice(5, 9);
            value = firstSegment + "-" + secondSegment + '-' + thirdSegment;
        }

        return value;
    }

    onRefreshClick(): void {
        abp.ui.setBusy();
        this.benAdminId = this.filters.benAdminId;
        this.groupId = this.filters.groupId;
        this.carrierId = this.filters.carrierId;
        this.loadMismatches();
    }

    private getBillMonths(): void {

        let currentYear = new Date().getFullYear();

        let monthArray = moment.monthsShort();

        for (let i = 0; i < monthArray.length; i++) {
            this.billMonths.push(monthArray[i] + ', ' + currentYear);
        }

        let currentMonthIndex = moment().format('M');

        this.filters.billingMonth = this.billMonths[+currentMonthIndex - 1];
    };

    benAdminOnChange(newValue): void {

        abp.ui.setBusy();

        this.filters.benAdminId = newValue;

        this._importCarrierDataAppServiceProxy.loadImportCarrierDataFilters(this.filters.benAdminId).finally(function () { abp.ui.clearBusy(); })
            .subscribe((res) => {

                let this_ = this;

                var defaultCarrier = new Carrier();
                defaultCarrier.carrierName = "No Carrier(s) Available";
                defaultCarrier.id = 0;

                this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

                this.groups = [];

                this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroups: [] }));

                _.forEach(res.groups.items, function (x) {
                    this_.groups.push(x);
                })

                this.groupId = this.filters.groupId = this.groups[0].id;
                this.carrierId = this.filters.carrierId = this.carriers.length > 0 ? this.carriers[0].id : defaultCarrier.id;

                this.setFiltersForReuse();
            });

    };

    //sets the filters in local forage so that we can access them across different components
    setFiltersForReuse(): void {
        this._storageService.setItem('filters', JSON.stringify(this.filters));
    }
}
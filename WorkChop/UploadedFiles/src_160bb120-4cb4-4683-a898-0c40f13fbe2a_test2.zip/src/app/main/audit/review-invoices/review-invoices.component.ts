﻿import { Component, OnInit, Injector, ViewEncapsulation, ViewChild, AfterViewInit, OnDestroy, Inject } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { AppComponentBase } from '@shared/common/app-component-base';
import { API_BASE_URL } from '@shared/service-proxies/service-proxies';
import * as _ from "lodash";
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { LocalStorageService } from '@shared/utils/local-storage.service';

import {
    BenAdmin,
    Carrier,
    CarrierServiceProxy,
    Group,
    GroupServiceProxy,
    FileServiceProxy,
    CarrierInvoiceServiceProxy,
    CarrierInvoiceDto,
    ImportCarrierDataAppServiceProxy,
    ImportJobAppServiceProxy,
    TokenAuthServiceProxy
} from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './review-invoices.component.html',
    animations: [appModuleAnimation()],
    styleUrls: ['./review-invoices.component.css']
})

export class ReviewInvoicesComponent extends AppComponentBase implements AfterViewInit, OnInit {

    reviewInvoicesFilters = new ReviewInvoicesFilters(null, null, null, null, null);

    uniqueGroups: Group[] = [];
    benAdmins: BenAdmin[] = [];
    carriers: Carrier[] = [];
    groups: any = [];
    result: any = [];
    months: Array<string> = [];
    reviewStates: any = [];

    public moment: any = moment;

    index: number = 0;
    isInEditMode: boolean = false;
    isAmountEqual: boolean = false;
    totalReviewedInvoice: number = 0;


    public carrierInvoice = new CarrierInvoiceDto();
    public coverageMonths: Array<any>;
    invoicePdfUrl: SafeUrl = undefined;
    public baseUrl: string = undefined;
    public reviewInvoicesData: any = [];
    public carrierCSV: any;
    private sub: any;
    public isInvoiceNumberRequired: boolean = false;
    public chkNoInvoiceNumber: boolean = false;


    constructor(private _injector: Injector,
        private _importCarrierDataService: ImportCarrierDataAppServiceProxy,
        private _sanitizer: DomSanitizer,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private _carrierInvoiceService: CarrierInvoiceServiceProxy,
        private _storageService: LocalStorageService,
        @Inject(API_BASE_URL) baseUrl?: string) {
        super(_injector);
        this.baseUrl = baseUrl ? baseUrl : "";
    }

    ngOnInit(): void {
        this._storageService.getItem('filters', (key, filters) => {
            this.loadImportCarrierDataFilters.call(this, filters);
        });
    }

    ngAfterViewInit(): void {

    }

    loadImportCarrierData(benAdminId): void {

        var self_ = this;

        this.getMonths();

        abp.ui.setBusy();

        //load import data filters
        this._importCarrierDataService.loadImportCarrierDataFilters(benAdminId).finally(function () { abp.ui.clearBusy(); }).subscribe((res) => {

            let this_ = this;

            this.benAdmins = res.benAdmins.items;

            var defaultCarrier = new Carrier();
            defaultCarrier.carrierName = "No Carrier(s) Available";
            defaultCarrier.id = 0;

            this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

            this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

            _.forEach(res.groups.items, function (x) {
                this_.groups.push(x);
            })

            this.reviewStates.push({ id: 0, stateName: "All" }, { id: 1, stateName: "NotReviewed" });

            this.reviewInvoicesFilters.benAdminId = this.reviewInvoicesFilters.benAdminId > 0 ? this.reviewInvoicesFilters.benAdminId : this.benAdmins[0].id;
            this.reviewInvoicesFilters.groupId = this.reviewInvoicesFilters.groupId > 0 ? this.reviewInvoicesFilters.groupId : this.groups[0].id;
            this.reviewInvoicesFilters.carrierId = this.reviewInvoicesFilters.carrierId > 0 ? this.reviewInvoicesFilters.carrierId : this.carriers[0].id;
            this.reviewInvoicesFilters.reviewStateId = this.reviewInvoicesFilters.reviewStateId > 0 ? this.reviewInvoicesFilters.reviewStateId : this.reviewStates[0].id;
            let currentMonthIndex = moment().format('M');
            this.reviewInvoicesFilters.billingMonth = this.reviewInvoicesFilters.billingMonth != undefined ? this.reviewInvoicesFilters.billingMonth : this.months[+currentMonthIndex - 1];

            this.getFilteredDataBasedOnSelectedFilters(this.reviewInvoicesFilters.benAdminId, this.reviewInvoicesFilters.carrierId, this.reviewInvoicesFilters.groupId, this.reviewInvoicesFilters.billingMonth, this.reviewInvoicesFilters.reviewStateId);

            this.setFiltersForReuse();
        })
    }

    loadImportCarrierDataFilters(filters): void {
        var filters = JSON.parse(filters);
        this.reviewInvoicesFilters.benAdminId = filters.benAdminId;
        this.reviewInvoicesFilters.carrierId = filters.carrierId;
        this.reviewInvoicesFilters.groupId = filters.groupId;
        this.reviewInvoicesFilters.billingMonth = filters.billingMonth;
        this.loadImportCarrierData(this.reviewInvoicesFilters.benAdminId);
    }

    private getMonths(): void {

        let currentYear = new Date().getFullYear();

        let monthArray = moment.monthsShort();

        for (let i = 0; i < monthArray.length; i++) {
            this.months.push(monthArray[i] + ', ' + currentYear);
        }
    };

    benAdminOnChange(newValue): void {
        abp.ui.setBusy();
        this.reviewInvoicesFilters.benAdminId = newValue;
        this._importCarrierDataService.loadImportCarrierDataFilters(this.reviewInvoicesFilters.benAdminId).finally(function () { abp.ui.clearBusy(); })
            .subscribe((res) => {

                let this_ = this;

                var defaultCarrier = new Carrier();
                defaultCarrier.carrierName = "No Carrier(s) Available";
                defaultCarrier.id = 0;

                this.carriers = (res.carriers !== null && res.carriers.items.length > 0) ? res.carriers.items : [defaultCarrier];

                this.groups = [];

                this.groups.push(new Group({ id: 0, employerName: "All", benAdminId: 0, carrierGroupsAccount: [] }));

                _.forEach(res.groups.items, function (x) {
                    this_.groups.push(x);
                })

                this.reviewInvoicesFilters.groupId = this.reviewInvoicesFilters.groupId = this.groups[0].id;
                this.reviewInvoicesFilters.carrierId = this.reviewInvoicesFilters.carrierId = this.carriers.length > 0 ? this.carriers[0].id : defaultCarrier.id;
                this.setFiltersForReuse();
            });
    };

    groupOnChange(groupId: number): void {
        this.reviewInvoicesFilters.groupId = groupId;
        this.setFiltersForReuse();
    };

    monthOnChange(newValue: string): void {
        this.reviewInvoicesFilters.billingMonth = newValue;
        this.setFiltersForReuse();
    }

    carrierOnChange(newVal): void {
        this.reviewInvoicesFilters.carrierId = newVal;
        this.setFiltersForReuse();
    }

    reviewStateOnChange(newVal): void {
        this.reviewInvoicesFilters.reviewStateId = newVal;
    }

    onRefreshClick() {
        this.isInEditMode = false;
        this.index = 0;
        abp.ui.setBusy();
        this.getFilteredDataBasedOnSelectedFilters(this.reviewInvoicesFilters.benAdminId, this.reviewInvoicesFilters.carrierId, this.reviewInvoicesFilters.groupId, this.reviewInvoicesFilters.billingMonth, this.reviewInvoicesFilters.reviewStateId);
    }
    onPreviousClick() {
        this.index--;
        this.bindInvoicePDFData(this.reviewInvoicesData[this.index]);
    }
    onNextClick() {
        this.index++;
        this.bindInvoicePDFData(this.reviewInvoicesData[this.index]);
    }

    onEditClick() {
        this.isInEditMode = true;
    }
    onCancelClick() {
        this.isInEditMode = false;
        this.bindInvoicePDFData(this.reviewInvoicesData[this.index]);
    }

    approveCarrierInvoice(): void {

        if (!this.chkNoInvoiceNumber) {
            if (this.carrierInvoice.invoiceNumber === '' || this.carrierInvoice.invoiceNumber === null || this.carrierInvoice.invoiceNumber === undefined) {
                this.isInvoiceNumberRequired = true;
                return;
            }
            else {
                this.isInvoiceNumberRequired = false;
            }
        }

        abp.ui.setBusy();
        this._carrierInvoiceService.approveCarrierInvoice(this.carrierInvoice)
            .finally(() => {
                this.isInEditMode = false;
                abp.ui.clearBusy();
                this.onRefreshClick();
                this.index = this.index === (this.reviewInvoicesData.length - 1) ? 0 : this.index + 1;
                this.bindInvoicePDFData(this.reviewInvoicesData[this.index]);
            })
            .subscribe((res) => {
            });
    }

    unApproveInvoice(id: any): void {
        this.message.confirm("Do you really want to remove the approval for this invoice?", isConfirmed => {
            if (isConfirmed) {
                abp.ui.setBusy();
                this._carrierInvoiceService.unApproveInvoice(id)
                    .finally(() => {
                        abp.ui.clearBusy();
                        this.onRefreshClick();
                    })
                    .subscribe((res) => {
                    });
            }
        })
    }

    matchTotalPremium(carrierCSV: any, carrierPDF: any): void {

        if (carrierCSV != null && carrierPDF != null) {

            let _csvInvoiceAmount = parseFloat(carrierCSV.totalBenefitPremium);

            let _pdfInvoiceAmount = parseFloat(carrierPDF.invoiceAmount);

            let _csvAdjustmentAmount = parseFloat(carrierCSV.totalAdjustment);

            let _pdfAdjustmentAmount = parseFloat(carrierPDF.adjustmentAmount);

            this.isAmountEqual = (_csvInvoiceAmount === _pdfInvoiceAmount) && (_csvAdjustmentAmount === _pdfAdjustmentAmount);
        }
    }

    bindInvoicePDFData(carrierGroupsAccount: any): void {
        this.carrierCSV = carrierGroupsAccount.carrierCSV;

        let carrierGroupAccountId = carrierGroupsAccount.carrierInvoice.carrierGroupAccountId === undefined ? carrierGroupsAccount.groupId : carrierGroupsAccount.carrierInvoice.carrierGroupAccountId;

        this.carrierInvoice.reviewed = carrierGroupsAccount.carrierInvoice.reviewed;

        this.carrierInvoice.id = carrierGroupsAccount.carrierInvoice.id;

        this.carrierInvoice.invoiceNumber = carrierGroupsAccount.carrierInvoice.invoiceNumber;

        this.chkNoInvoiceNumber = this.carrierInvoice.invoiceNumber === 'N/A' ? true : false;

        this.carrierInvoice.invoiceFileName = carrierGroupsAccount.carrierInvoice.invoiceFileName;

        this.carrierInvoice.carrierGroupAccountId = +carrierGroupAccountId;

        this.carrierInvoice.receiptionMethod = carrierGroupsAccount.carrierInvoice.receiptionMethod !== null ? carrierGroupsAccount.carrierInvoice.receiptionMethod.trim() : 'Email'; //default to Email

        this.carrierInvoice.benefitTypes = carrierGroupsAccount.benefitDefinition.benefitType;

        this.carrierInvoice.coverageStartDate = carrierGroupsAccount.carrierInvoice.coverageStartDate !== null ? moment(carrierGroupsAccount.carrierInvoice.coverageStartDate).format("MMM, YYYY") : null;

        this.carrierInvoice.dateReceived = carrierGroupsAccount.carrierInvoice.dateReceived !== null ? moment(carrierGroupsAccount.carrierInvoice.dateReceived).format("YYYY-MM-DD") : null;

        this.carrierInvoice.dueDate = carrierGroupsAccount.carrierInvoice.dueDate !== null ? moment(carrierGroupsAccount.carrierInvoice.dueDate).format("YYYY-MM-DD") : null;

        this.carrierInvoice.invoiceAmount = carrierGroupsAccount.carrierInvoice.invoiceAmount !== null ? carrierGroupsAccount.carrierInvoice.invoiceAmount.toFixed(2) : 0.00.toFixed(2);

        this.carrierInvoice.adjustmentAmount = carrierGroupsAccount.carrierInvoice.adjustmentAmount !== null ? carrierGroupsAccount.carrierInvoice.adjustmentAmount.toFixed(2) : 0.00.toFixed(2);

        this.carrierInvoice.totalPremiumAmount = parseFloat(carrierGroupsAccount.carrierInvoice.totalPremiumAmount).toFixed(2);

        this.carrierInvoice.accountNumber = carrierGroupsAccount.accountNumber;

        let url = this.baseUrl + "/api/services/app/CarrierInvoice/GetCarrierInvoicePdf?id=" + carrierGroupsAccount.carrierInvoice.id;
        this.invoicePdfUrl = this._sanitizer.bypassSecurityTrustResourceUrl(url);

        this.coverageMonths = this.getCoverageMonths();

        this.matchTotalPremium(this.carrierCSV, this.carrierInvoice);
    }
    getFilteredDataBasedOnSelectedFilters(benAdminId: number, carrierId: number, groupId: any, billingMonth: string, reviewState: any): void {

        //this will load the selected filters data
        this._importCarrierDataService.getCarrierInvoiceData(benAdminId, carrierId, groupId, billingMonth, reviewState)
            .finally(function () { this.loading = false; abp.ui.clearBusy(); })
            .subscribe((response) => {
                this.reviewInvoicesData = [];
                if (response.length > 0) {
                    this.reviewInvoicesData = _.filter(response, function (x: any) { return x.carrierInvoice !== null })
                }
                if (this.reviewInvoicesData.length > 0)
                    this.bindInvoicePDFData(this.reviewInvoicesData[this.index]);


                this.totalReviewedInvoice = _.filter(this.reviewInvoicesData, function (x: any) { return x.carrierInvoice.reviewed === true }).length;

            });
    }


    getCoverageMonths(): Array<any> {
        return [
            {
                "text": moment().add(-1, 'month').format('MMM'),
                "monthsToAdd": -1,
                "postfix": "",
                "style": { 'float': 'left', "font-style": "italic", "cursor": "pointer" }
            },
            {
                "text": moment().format('MMM'),
                "monthsToAdd": 0,
                "postfix": " (Current) ",
                "style": { 'text-align': 'center', 'margin-left': '32px', "font-style": "italic", "font-weight": "700", "cursor": "pointer" }
            },
            {
                "text": moment().add(1, 'month').format('MMM'),
                "postfix": "",
                "monthsToAdd": 1,
                "style": { 'float': 'right', "font-style": "italic", "cursor": "pointer" }
            }
        ]
    }

    currentMonthlyPremiumOnChange(value: string) {
        value = value === '' ? '0' : value;
        this.carrierInvoice.totalPremiumAmount = (parseFloat(value) + parseFloat(String(this.carrierInvoice.adjustmentAmount))).toFixed(2);
        this.matchTotalPremium(this.carrierCSV, this.carrierInvoice);
    }

    adjustmentAmountOnChange(value: string) {
        value = value === '' ? '0' : value;
        this.carrierInvoice.totalPremiumAmount = (parseFloat(value) + parseFloat(String(this.carrierInvoice.invoiceAmount))).toFixed(2);
        this.matchTotalPremium(this.carrierCSV, this.carrierInvoice);
    }

    noInvoiceOnChange(event: any): void {

        let isChecked = event.target.checked;

        this.isInvoiceNumberRequired = !isChecked;

        if (isChecked) {
            $('#invoiceNumber').attr("disabled", "disabled");
            this.carrierInvoice.invoiceNumber = 'N/A';
        }
        else {
            $('#invoiceNumber').removeAttr("disabled");
            this.carrierInvoice.invoiceNumber = '';
        }
    }

    receiptionMethodOnChange(receiptionMethod: string): void {
        this.carrierInvoice.receiptionMethod = receiptionMethod;
    }

    //this will redirect to ImportDataComponent
    redirectToImportDataComponent(): void {
        this.router.navigate(['app/main/audit/import-data']);
    }

    //sets the filters in local forage so that we can access them across different components
    setFiltersForReuse(): void {
        this._storageService.setItem('filters', JSON.stringify(this.reviewInvoicesFilters));
    }
}

export class ReviewInvoicesFilters {
    constructor(
        public benAdminId?: number,
        public groupId?: number,
        public reviewStateId?: number,
        public billingMonth?: string,
        public carrierId?: number
    ) { }
}

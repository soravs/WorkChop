﻿import { Component, Injector, OnInit } from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { BenAdminServiceProxy, ListResultDtoOfBenAdmin, BenAdmin } from '@shared/service-proxies/service-proxies'

@Component({
    templateUrl: './benadmins.component.html',
    animations: [appModuleAnimation()]
})
export class BenAdminsComponent extends AppComponentBase implements OnInit {

    benAdmins: BenAdmin[] = [];

    constructor(
        injector: Injector,
        private benAdminService: BenAdminServiceProxy
    ) {
        super(injector);
    }

    ngOnInit(): void {

        this.benAdminService.getBenAdmins()
            .subscribe((res) => { this.benAdmins = res.items; });
    }
}
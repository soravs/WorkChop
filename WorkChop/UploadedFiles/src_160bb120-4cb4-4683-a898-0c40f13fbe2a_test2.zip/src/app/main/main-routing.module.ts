import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Route } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BenAdminsComponent } from './benadmins/benadmins.component';
import { AuditImportDataComponent } from './audit/import-data/import-data.component';
import { ResolveNameMismatchComponent } from './audit/resolve-name-mismatches/resolve-name-mismatch.component';
import { ReviewInvoicesComponent } from './audit/review-invoices/review-invoices.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                children: [
                    {
                        path:
                        'dashboard', component: DashboardComponent,
                        data: { permission: 'Pages.Tenant.Dashboard' }
                    },
                    {
                        path:
                        'benadmins', component: BenAdminsComponent
                    },
                    {
                        path: 'audit/import-data',
                        component: AuditImportDataComponent
                    },
                    {
                        path: 'audit/resolve-name-mismatches',
                        component: ResolveNameMismatchComponent
                    },
                    {
                        path: 'audit/review-invoices',
                        component: ReviewInvoicesComponent
                    }
                ]
            }
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class MainRoutingModule { }
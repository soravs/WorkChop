import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DashboardComponent } from './dashboard/dashboard.component';

import { ModalModule, TabsModule, TooltipModule, TypeaheadModule } from 'ng2-bootstrap';
import { AppCommonModule } from '@app/shared/common/app-common.module';
import { UtilsModule } from '@shared/utils/utils.module';
import { MainRoutingModule } from './main-routing.module';
import { BenAdminsComponent } from './benadmins/benadmins.component'
import { AuditImportDataComponent } from './audit/import-data/import-data.component';
import { ResolveNameMismatchComponent } from './audit/resolve-name-mismatches/resolve-name-mismatch.component';
import { FileUploadModule } from '@node_modules/ng2-file-upload';
import { CarrierInvoicePDFModalComponent } from '@app/main/audit/import-data/carrier-invoice-pdf-modal.component';
import { ReviewInvoicesComponent } from './audit/review-invoices/review-invoices.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ModalModule,
        TabsModule,
        TooltipModule,
        AppCommonModule,
        UtilsModule,
        MainRoutingModule,
        FileUploadModule,
        TypeaheadModule.forRoot()
    ],
    declarations: [
        DashboardComponent,
        BenAdminsComponent,
        AuditImportDataComponent,
        ResolveNameMismatchComponent,
        CarrierInvoicePDFModalComponent,
        ReviewInvoicesComponent
    ]
})
export class MainModule { }
﻿import { Directive, ElementRef, Input, AfterViewInit, OnInit } from '@angular/core';
import * as _ from "lodash";

@Directive({
    selector: "[format-ssn]"
})

//This directive will check the differences between the first name and last name i.e. received from 
//ben admin and carrier and then show the differences in red colour on UI
export class FormatSSN implements OnInit {

    @Input() ssn: any = null;

    private dom: any = null;

    constructor(
        private _element: ElementRef
    ) { this.dom = _element.nativeElement }

    ngOnInit(): void {
        
        let receivedSSN: string = this.ssn;

        let formattedSSN = receivedSSN.replace(/^(\d{3})\s?\-?\s?(\d{2})\s?\-?\s?(\d{4})$/, "$1-$2-$3");

        this.dom.innerHTML = formattedSSN;
    }

    ngAfterViewInit(): void {

      
    }
}

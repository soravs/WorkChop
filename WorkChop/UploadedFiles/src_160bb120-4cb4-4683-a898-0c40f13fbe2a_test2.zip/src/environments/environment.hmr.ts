// "Hot Module Replacement" enabled environment

export const environment = {
    production: false,
    hmr: true
};

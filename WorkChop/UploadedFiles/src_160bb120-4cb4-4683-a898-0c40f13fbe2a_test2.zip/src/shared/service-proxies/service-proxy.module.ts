﻿import { NgModule } from '@angular/core';

import * as ApiServiceProxies from './service-proxies';

@NgModule({
    providers: [
        ApiServiceProxies.AuditLogServiceProxy,
        ApiServiceProxies.CachingServiceProxy,
        ApiServiceProxies.ChatServiceProxy,
        ApiServiceProxies.CommonLookupServiceProxy,
        ApiServiceProxies.EditionServiceProxy,
        ApiServiceProxies.FriendshipServiceProxy,
        ApiServiceProxies.HostSettingsServiceProxy,
        ApiServiceProxies.LanguageServiceProxy,
        ApiServiceProxies.NotificationServiceProxy,
        ApiServiceProxies.OrganizationUnitServiceProxy,
        ApiServiceProxies.PermissionServiceProxy,
        ApiServiceProxies.ProfileServiceProxy,
        ApiServiceProxies.RoleServiceProxy,
        ApiServiceProxies.SessionServiceProxy,
        ApiServiceProxies.TenantServiceProxy,
        ApiServiceProxies.TenantDashboardServiceProxy,
        ApiServiceProxies.TenantSettingsServiceProxy,
        ApiServiceProxies.TimingServiceProxy,
        ApiServiceProxies.UserServiceProxy,
        ApiServiceProxies.UserLinkServiceProxy,
        ApiServiceProxies.UserLoginServiceProxy,
        ApiServiceProxies.WebLogServiceProxy,
        ApiServiceProxies.AccountServiceProxy,
        ApiServiceProxies.TokenAuthServiceProxy,
        ApiServiceProxies.TenantRegistrationServiceProxy,
        ApiServiceProxies.BenAdminServiceProxy,
        ApiServiceProxies.CarrierServiceProxy,
        ApiServiceProxies.GroupServiceProxy,
        ApiServiceProxies.FileServiceProxy,
        ApiServiceProxies.BenefitDefinitionProxy,
        ApiServiceProxies.CarrierInvoiceServiceProxy,
        ApiServiceProxies.ImportCarrierDataAppServiceProxy,
        ApiServiceProxies.ImportJobAppServiceProxy,
        ApiServiceProxies.ResolveNameMismatchServiceProxy,
        ApiServiceProxies.SubscriberAppServiceProxy,
        ApiServiceProxies.DiscrepancyServiceProxy,
        ApiServiceProxies.TpaJobAppServiceProxy
    ]
})
export class ServiceProxyModule { }
